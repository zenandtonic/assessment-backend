const express = require("express");
const cors = require("cors");

const app = express();


app.use(cors());

app.use(express.json()); // When we want to be able to accept JSON.


app.get('/api/inventory', (req, res) => {
  const inventory = ['knife', 'spoon', 'fork', 'spork'];

  let randomInventoryIndex = Math.floor(Math.random() * inventory.length);
  let randomInventory = inventory[randomInventoryIndex];

  res.status(200).send(randomInventory);
});


app.get('/api/fortunes', (req, res) => {
  const fortunes = ["Money is on the way", "Opportunity is knocking - open the door", 
  "Today is a good day to start your diet", "The meek shall inherit the earth", "The humble shall not be put to shame"];      

  let randomFortuneIndex = Math.floor(Math.random() * fortunes.length);
  let randomFortune = fortunes[randomFortuneIndex];

  res.status(200).send(randomFortune);
});

app.get("/api/compliment", (req, res) => {
  const compliments = ["Gee, you're a smart cookie!",
					 "Cool shirt!",
					 "Your Javascript skills are stellar.",
  ];

  // choose random compliment
  let randomIndex = Math.floor(Math.random() * compliments.length);
  let randomCompliment = compliments[randomIndex];

  res.status(200).send(randomCompliment);
  
});

let books = [];

app.use(cors());

app.use(bodyParser.urlencoded( { extended: false }));
app.use(bodyParser.json());

app.post('/book', (req, res) => {
    const book = req.body;

    console.log(book);
    books.push(book);

    res.send('Book is added to the database');
});
app.listen(4000, () => console.log("Server running on 4000"));
